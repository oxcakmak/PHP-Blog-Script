<?php
$route = array();
$route['404'] = '404';
$route['add'] = 'add';
$route['admin'] = 'admin';
$route['article'] = 'article';
$route['articles'] = 'article/';
$route['blog'] = 'blog';
$route['blogs'] = 'blog/';
$route['contact'] = 'contact';
$route['edit'] = 'edit';
$route['file'] = 'file';
$route['home'] = 'home';
$route['login'] = 'login';
$route['logout'] = 'logout';
$route['page'] = 'page';
$route['pages'] = 'page/';
$route['settings'] = 'settings';

/*
$route['REPLACE_ME'] = 'REPLACE_ME';
*/
?>